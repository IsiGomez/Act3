const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Datos de prueba (Mock Data)
const products = [
  { id: 1, nombre: 'Laptop HP Pavilion', precio: 650000, descripcion: 'Laptop Intel Core i5 16GB RAM' },
  { id: 2, nombre: 'Mouse Inalámbrico Logitech', precio: 19990, descripcion: 'Mouse ergonómico receptor USB' },
  { id: 3, nombre: 'Teclado Mecánico Redragon', precio: 45000, descripcion: 'Teclado RGB con switches azules' },
  { id: 4, nombre: 'Monitor LG 24 Full HD', precio: 120000, descripcion: 'Monitor IPS 75Hz HDMI' }
];

// Ruta 1: Obtener todos los productos
app.get('/api/products', (req, res) => {
  res.json(products);
});

// Ruta 2: Obtener un producto por ID
app.get('/api/products/:id', (req, res) => {
  const productId = parseInt(req.params.id);
  const product = products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).json({ mensaje: 'Producto no encontrado' });
  }

  res.json(product);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

module.exports = app;